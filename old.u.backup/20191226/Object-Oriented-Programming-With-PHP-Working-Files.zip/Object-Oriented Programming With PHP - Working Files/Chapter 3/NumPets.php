<?php

class NumPets
{
    private $aNumPets;

	public function getNumPets()
	{
		return $this->aNumPets;
	}

	public function setNumPets($aNum)
	{
		$this->aNumPets = $aNum;
	}
}

?>