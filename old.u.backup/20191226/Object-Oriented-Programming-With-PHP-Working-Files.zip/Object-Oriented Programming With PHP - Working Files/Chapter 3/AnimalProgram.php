<?php

include "Animal.php";

$myDog = new Dog();
$myDog->showDog("Lassie");

$myDog->showType();

?>
