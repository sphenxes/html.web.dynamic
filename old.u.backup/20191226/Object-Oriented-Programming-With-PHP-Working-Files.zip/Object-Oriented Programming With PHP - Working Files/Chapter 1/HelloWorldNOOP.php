<!DOCTYPE html>

<html>
<head>
	<title>HelloWorld - NOOP</title>
</head>

<body>
<h1>HelloWorld - NOOP (Not OOP)</h1>

<?php
	$myMsg = "Hello World";
	print "<br>".$myMsg;
?>

</body>
</html>
